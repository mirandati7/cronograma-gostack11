# Cronograma de estudos

## 📅 Cronograma semanal

[Meu cronograma semanal](https://www.notion.so/59381d63a77645e49f322da5f2c3fd0d)

## 📅 Cronograma diário

[Calendário de estudos](https://www.notion.so/ce71bc8d5f9845f3a699c4b597c7ef75)